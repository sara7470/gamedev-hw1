﻿using System;

namespace hw1
{
    class Program
    {
        static void Main(string[] args)
        {
            //string hero = "Tom";
            int health = 100;

            int damaged(int damage)
            {
                return health - damage;
            }

            int playerHP = damaged(20);
            Console.WriteLine("Damaged Health is : " + playerHP);

            int boost(int boost)
            {
                return playerHP + boost;
            }

            int boostedHP = boost(10);
            Console.WriteLine("Boosted Health is : " + boostedHP);

            int[] HealthArray = { playerHP, boostedHP };
            Console.WriteLine(HealthArray[1]);

            Console.WriteLine(playerHP + " is less than " + boostedHP);
               
        }
    }
}
